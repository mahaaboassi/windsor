import type React from "react"
import { useEffect, useState } from "react";
import { Link } from "react-router-dom"
import { motion, AnimatePresence } from "framer-motion";

const FixedComponent: React.FC = ()=>{
    const [show, setShow] = useState(false);
    useEffect(() => {
        const timer = setTimeout(() => setShow(true), 800); // delay
        return () => clearTimeout(timer);
    }, []);
    return(<div>
        <AnimatePresence>
                {show && (
                    <motion.div
                    style={{zIndex:"100"}}
                        initial={{ opacity: 0, y: 40, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 40 }}
                        transition={{ duration: 0.6, ease: "easeOut" }}
                        className="
                            fixed right-4 bottom-28 card-pop-up w-72 max-w-[90%] 
                            bg-white/90 backdrop-blur-xl 
                            text-gray-700 shadow-[0_8px_30px_rgba(0,0,0,0.12)]
                            rounded-2xl border border-white/60
                            p-4
                        "
                        >
                        <div className="flex items-start justify-between gap-3">
                            <p className="text-sm leading-relaxed font-medium">
                            Welcome! Looking for dental care or a consultation?<br />
                            Our team is ready to assist you with any concerns.
                            </p>

                            <button
                            onClick={() => setShow(false)}
                            className="text-gray-400 hover:text-gray-600 transition cursor-pointer"
                            >
                            ✕
                            </button>
                        </div>
                        </motion.div>
                )}
        </AnimatePresence>
        <div className="fixed right-3 bottom-3 xxs:right-6 xxs:bottom-6 z-60 fixed-component">
            <Link target="_blank" aria-label="Whatsapp" to={"https://wa.me/+61419358029"}>
                <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80" fill="none">
                <path d="M39 0.5H76C77.933 0.500001 79.5 2.067 79.5 4V41C79.5 62.263 62.263 79.5 41 79.5H39C17.737 79.5 0.500001 62.263 0.5 41V39C0.500001 18.0694 17.2024 1.03999 38.0059 0.512695L39 0.5Z" fill="#A6CE38"/>
                <path d="M39 0.5H76C77.933 0.500001 79.5 2.067 79.5 4V41C79.5 62.263 62.263 79.5 41 79.5H39C17.737 79.5 0.500001 62.263 0.5 41V39C0.500001 18.0694 17.2024 1.03999 38.0059 0.512695L39 0.5Z" stroke="#EEEEEE"/>
                <path d="M47.7689 49.2752C38.4642 49.2731 30.8927 41.5339 30.8906 32.0252C30.8948 29.6153 32.8119 27.6536 35.1676 27.6536C35.4095 27.6536 35.6495 27.6747 35.877 27.717C36.3816 27.8015 36.8593 27.977 37.3019 28.2391C37.366 28.2772 37.4095 28.3406 37.4198 28.4146L38.4022 34.7501C38.4146 34.8241 38.3918 34.8981 38.3443 34.9531C37.8004 35.5682 37.1075 36.0101 36.3382 36.232L35.968 36.3399L36.1086 36.7077C37.3784 40.0076 39.9595 42.6479 43.19 43.9459L43.5498 44.0897L43.6532 43.7091C43.8704 42.9206 44.3026 42.2125 44.9045 41.6586C44.9479 41.6184 45.0058 41.5952 45.0658 41.5952C45.0782 41.5952 45.0927 41.5952 45.1051 41.5994L51.3013 42.6035C51.3757 42.6162 51.4357 42.6585 51.475 42.724C51.7294 43.1764 51.9011 43.6669 51.9859 44.1806C52.0251 44.411 52.0458 44.652 52.0458 44.9057C52.0458 47.3135 50.1266 49.2731 47.7689 49.2773V49.2752Z" fill="white"/>
                <path d="M64.2678 36.3215C63.7652 30.525 61.1676 25.1491 56.9527 21.1855C52.713 17.1964 47.2096 15 41.456 15C28.8278 15 18.5532 25.5022 18.5532 38.4101C18.5532 42.7416 19.7217 46.9632 21.9346 50.6394L17 61.8075L32.8049 60.0867C35.5534 61.2367 38.4634 61.8202 41.456 61.8202C42.244 61.8202 43.0505 61.7779 43.8592 61.6933C44.5727 61.6151 45.2924 61.5009 46.0018 61.3551C56.5784 59.1714 64.2988 49.5761 64.3588 38.5348V38.4101C64.3588 37.7061 64.3278 37.0043 64.2657 36.3236L64.2678 36.3215ZM33.4108 55.1844L24.6667 56.1357L27.2787 50.2229L26.7576 49.5063C26.7183 49.4535 26.681 49.4006 26.6376 49.3414C24.3709 46.143 23.1734 42.3632 23.1734 38.408C23.1734 28.1024 31.3758 19.7205 41.456 19.7205C50.9013 19.7205 58.905 27.2526 59.6765 36.8669C59.7178 37.3827 59.7385 37.9006 59.7385 38.4101C59.7385 38.556 59.7364 38.6997 59.7323 38.8519C59.5379 47.4727 53.6457 54.7933 45.4041 56.6579C44.7754 56.8016 44.1301 56.9094 43.4869 56.9813C42.8189 57.0595 42.1343 57.0976 41.4539 57.0976C39.0321 57.0976 36.6785 56.6177 34.4532 55.6706C34.2071 55.5692 33.9651 55.4614 33.7376 55.3493L33.4067 55.1865L33.4108 55.1844Z" fill="white"/>
                </svg>
            </Link>
        </div>
    </div>)
}
export default FixedComponent