import HeroForDynamicPages from "../../components/heroForDynamicPages"
// Images
import img_1 from "../../assets/images/test.png"
import img_2 from "../../assets/images/test_1.png"
import { categories } from "../../data"
import { useNavigate, useParams } from "react-router-dom"
import { useEffect, useState, type ReactNode } from "react"
import Ready from "../../sections/ready"
import Heading from "../../components/heading"
import Reviews from "../../sections/review"
import Consultation from "../../sections/consultation"


type Service = {
    icon: string;
    link?: string;
    title: string;
    desc: string;
};

type Section = {
    img: string;
    hint: string;
    title: string;
    desc_1: ReactNode;
    service?: Partial<Service>[];
};

type Hero = {
    hint: string;
    title: string;
    desc: string;
    subLabel: string;
};
type Services = {
    id: number;
    link: string,
    hero: Hero;
    sections: Section[];
}
type Item = {
    id: number;
    link: string;
    category : string;
    services : Services[],
    first_sections : Section,
    second_section : Section,
    img: string,
    img_sm: string

};

const CategoryOfService = ()=>{
    const navigate = useNavigate()
    const { category} = useParams()
    // const [ data, setData ] = useState<Services[] | undefined>(undefined)
    const [cat, setCat] = useState<Item | undefined>(undefined);
    useEffect(()=>{
        if (!category) return;
        window.scrollTo({top:0})
        const catValue = categories.find(e => e.link === `/${category}`);
        if(!catValue) navigate("/")
        setCat(catValue)
    },[category])
    return(<div className="flex flex-col gap-10 md:gap-20 dynamic-pages">
        <HeroForDynamicPages img={cat?.img ?? ""} img_sm={cat?.img_sm ?? ""}  hint={cat?.category ?? ""} title={"In Windsor"}
                            desc={""}
                            link={"/"} label={"Home"} subLabel={cat?.category ??  ""}
        />
        <Reviews/>
        <Consultation/>
        <div className="flex flex-col-reverse lg:grid lg:grid-cols-2 gap-5 container-layout">
            <div className="flex flex-col gap-5">
                <Heading hint={cat?.first_sections.hint ?? ""} title={cat?.first_sections.title ?? ""} desc=""/>
                <div className="desc">{cat?.first_sections.desc_1}</div>
            </div>
            <div className="relative">
                <div className="sticky top-30"><img src={img_2} alt="Image" /></div>
            </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 container-layout">
            <div className="relative">
                <div className="sticky top-30"><img src={img_1} alt="Image" /></div>
            </div>
            <div className="flex flex-col gap-5 md:gap-10">
                <Heading hint={cat?.second_section.hint ?? ""} title={cat?.second_section.title ?? ""} desc=""/>
                <div className="desc">{cat?.second_section.desc_1}</div>
                <div className="flex flex-col gap-3">
                    {
                        cat?.second_section.service?.map((e,idx)=>(
                            <div key={`${e.title}_${idx}`} className="flex gap-3">
                                <div className="w-[20px] h-[20px] border border-[2px] border-[var(--grey_2)] rounded-full bg-[var(--main)] flex justify-center items-center"></div>
                                <div className="flex flex-col gap-1 w-full option">
                                    <div className="title">{e.title}</div>
                                    <p>{e.desc}</p>
                                </div>
                            </div>
                        ))
                    }

                </div>
            </div>
            
        </div>
        <Ready/>
    </div>)
}
export default CategoryOfService