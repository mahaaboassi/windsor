import HeroForDynamicPages from "../../components/heroForDynamicPages"
// Images
import img_1 from "../../assets/images/img.png"
import img_2 from "../../assets/images/about.png"
import { categories } from "../../data"
import { useParams } from "react-router-dom"
import { useEffect, useState, type ReactNode } from "react"
import Ready from "../../sections/ready"
import Heading from "../../components/heading"

type Service = {
    icon: string;
    link?: string;
    title: string;
    desc: string;
};

type Section = {
    img: string;
    hint: string;
    title: string;
    desc_1: ReactNode;
    service?: Partial<Service>[];
};

type Hero = {
    hint: string;
    title: string;
    desc: string;
    subLabel: string;
};
type Services = {
    id: number;
    link: string,
    hero: Hero;
    sections: Section[];
}
type Item = {
    id: number;
    link: string;
    category : string;
    services : Services[],
    first_sections : Section,
    second_section : Section
};

const Service = ()=>{
    const { category, link} = useParams()
    const [ data, setData ] = useState<Services | undefined>(undefined)
      const [cat, setCat] = useState<Item | undefined>(undefined);
    useEffect(()=>{
        if (!category || !link) return;
        window.scrollTo({top:0})
        const catValue = categories.find(e => e.link === `/${category}`);
        const service = catValue?.services.find(e => e.link === `${category}/${link}`);
        setCat(catValue)
        setData(service);
    },[link,category])
    return(<div className="flex flex-col gap-10 md:gap-20 dynamic-pages">
        <HeroForDynamicPages hint={data?.hero?.hint ?? ""} title={data?.hero?.title ?? ""}
                            desc={data?.hero?.desc ?? ""}
                            link={cat?.link ?? ""} label={cat?.category ?? ""} subLabel={data?.hero?.subLabel ?? ""}
        />
        <div className="flex flex-col-reverse lg:grid lg:grid-cols-2 gap-5 container-layout">
            <div className="flex flex-col gap-5 md:gap-10">
                <Heading desc="" title={data?.sections[0].title ?? ""} hint={data?.sections[0].hint ?? ""} />
                <div className="desc">{data?.sections[0].desc_1}</div>
            </div>
            <div className="relative">
                <div className="sticky top-30"><img src={img_2} alt="Image" /></div>
            </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 container-layout">
            <div className="relative">
                <div className="sticky top-30"><img src={img_1} alt="Image" /></div>
            </div>
            <div className="flex flex-col gap-5 md:gap-10">
                <Heading desc="" title={data?.sections[1].title ?? ""} hint={data?.sections[1].hint ?? ""} />
                <div className="desc">{data?.sections[1].desc_1}</div>
                <div className="flex flex-col gap-3">
                    {
                        data?.sections[1].service?.map((e,idx)=>(
                            <div key={`${e.title}_${idx}`} className="flex gap-3 option">
                                <div className="w-[20px] h-[20px] border border-[2px] border-[var(--grey_2)] rounded-full bg-[var(--main)] flex justify-center items-center"></div>
                                <div className="flex flex-col gap-1 w-full">
                                    <div className="title">{e.title}</div>
                                    <p>{e.desc}</p>
                                </div>
                            </div>
                        ))
                    }

                </div>
            </div>
            
        </div>
        <Ready/>
    </div>)
}
export default Service